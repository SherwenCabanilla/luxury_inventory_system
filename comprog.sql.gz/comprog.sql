-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2023 at 01:56 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `comprog`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(16) NOT NULL,
  `Username` varchar(16) NOT NULL,
  `Password` varchar(16) NOT NULL,
  `Position` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `Username`, `Password`, `Position`) VALUES
(1, 'admin1', 'admin1', 'Project Manager'),
(2, 'admin2', 'admin2', 'Senior Developer'),
(3, 'admin3', 'admin3', 'Senior Developer'),
(4, 'admin3', 'admin3', 'Senior Developer'),
(5, 'admin3', 'admin3', 'Senior Developer');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ID` int(11) NOT NULL,
  `Brand` varchar(255) NOT NULL,
  `ProductName` varchar(255) NOT NULL,
  `Price` double DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ID`, `Brand`, `ProductName`, `Price`, `Quantity`) VALUES
(1, 'CHANEL', 'Chanel Classic Flap Bag', 2500, 5),
(2, 'CHANEL', 'Chanel Coco Mademoiselle Perfume', 150, 10),
(3, 'CHANEL', 'Chanel Boy Bag', 3500, 3),
(4, 'CHANEL', 'Chanel No. 5 Perfume', 200, 15),
(5, 'CHANEL', 'Chanel Gabrielle Backpack', 2800, 2),
(6, 'CHANEL', 'Chanel Rouge Coco Lipstick', 40, 20),
(7, 'CHANEL', 'Chanel Le Vernis Nail Polish', 28, 30),
(8, 'CHANEL', 'Chanel J12 Watch', 5500, 1),
(9, 'CHANEL', 'Chanel Chance Eau Tendre Perfume', 130, 12),
(10, 'CHANEL', 'Chanel Coco Noir Perfume', 180, 8),
(11, 'PRADA', 'Prada Saffiano Leather Tote', 2500, 5),
(12, 'PRADA', 'Prada Candy Perfume', 150, 10),
(13, 'PRADA', 'Prada Galleria Bag', 3500, 3),
(14, 'PRADA', 'Prada Luna Rossa Cologne', 200, 15),
(15, 'PRADA', 'Prada Cahier Shoulder Bag', 2800, 2),
(16, 'PRADA', 'Prada Double Strap Sandals', 690, 20),
(17, 'PRADA', 'Prada Nylon Belt Bag', 595, 10),
(18, 'PRADA', 'Prada Saffiano Wallet', 500, 23),
(19, 'PRADA', 'Prada L Homme Cologne', 120, 12),
(20, 'PRADA', 'Prada Amber Perfume', 180, 8),
(21, 'FENDI', 'Fendi Peekaboo Bag', 3500, 5),
(22, 'FENDI', 'Fendi L Acquarossa Perfume', 150, 10),
(23, 'FENDI', 'Fendi Baguette Bag', 2500, 3),
(24, 'FENDI', 'Fendi Fan di Fendi Perfume', 200, 15),
(25, 'FENDI', 'Fendi Kan U Bag', 2800, 2),
(26, 'FENDI', 'Fendi FF Logo Sneakers', 595, 20),
(27, 'FENDI', 'Fendi FF Logo Belt', 450, 10),
(28, 'FENDI', 'Fendi Runaway Tote', 2500, 5),
(29, 'FENDI', 'Fendi L Acquarossa Eau de Toilette', 120, 12),
(30, 'FENDI', 'Fendi Furiosa Perfume', 180, 32),
(31, 'GUCCI', 'Gucci GG Marmont Matelassé Bag', 2500, 5),
(32, 'GUCCI', 'Gucci Bloom Perfume', 150, 10),
(33, 'GUCCI', 'Gucci Dionysus Bag', 3500, 3),
(34, 'GUCCI', 'Gucci Guilty Perfume', 200, 15),
(35, 'GUCCI', 'Gucci Ophidia GG Supreme Belt Bag', 2800, 2),
(36, 'GUCCI', 'Gucci Ace Sneakers', 595, 20),
(37, 'GUCCI', 'Gucci Princetown Leather Slipper', 690, 10),
(38, 'GUCCI', 'Gucci Horsebit 1955 Shoulder Bag', 1980, 5),
(39, 'GUCCI', 'Gucci Bamboo Eau de Parfum', 120, 12),
(40, 'GUCCI', 'Gucci Guilty Love Edition Perfume', 180, 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
