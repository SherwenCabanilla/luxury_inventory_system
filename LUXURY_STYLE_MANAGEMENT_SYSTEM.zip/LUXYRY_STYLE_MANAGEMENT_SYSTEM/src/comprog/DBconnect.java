/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package comprog;

/**
 *
 * @author ADMIN
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author ADMIN
 */
import java.sql.*;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DBconnect {

    private static String url = "jdbc:mysql://localhost:3306/comprog";
    private static String username = "root";
    private static String password = "password";
    private static Connection conn = null;
    private static ResultSet rs = null;
    private static Statement statement = null;
    private static PreparedStatement smtm = null;

    private String brand;
    private String productName;
    private String price;
    private String quantity;
    private String id;
    static String adminUsername;
    private String adminPassword;
    static String Position;
    private String loginSuccessfully;
    private String loginFailed;
    DefaultTableModel tbModel;

    public String getLoginFailed() {
        return loginFailed;
    }

    public void setLoginFailed(String loginFailed) {
        this.loginFailed = loginFailed;
    }

    public String getLoginSuccessfully() {
        return loginSuccessfully;
    }

    public void setLoginSuccessfully(String loginSuccessfully) {
        this.loginSuccessfully = "saanasjhs";
        this.loginSuccessfully = loginSuccessfully;
    }

    public String getAdminUsername() {
        return adminUsername;
    }

    public void setAdminUsername(String adminUsername) {
        this.adminUsername = adminUsername;
    }

    public String getAdminPassword() {
        return adminPassword;
    }

    public void setAdminPassword(String adminPassword) {
        this.adminPassword = adminPassword;
    }

    public String getPosition() {
        return Position;
    }

    public void setPosition(String Position) {
        this.Position = Position;
    }

    public String getID() {
        return id;
    }

    public void setID(String id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public void toConnect() {
        try {
            conn = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//    ADD PRODUCT TO DATABASE
    public void addProduct(String Brand, String ProductName, double Price, int quantity) {
        String insertQuery = "INSERT INTO product (Brand, ProductName, Price, Quantity) VALUES (?, ?, ?, ?)";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            toConnect();

            if (isProductExists(conn, ProductName)) {
                JOptionPane.showMessageDialog(null, "The Product: " + ProductName + " is already in Database!", "Alert", JOptionPane.WARNING_MESSAGE);
                return;
            }
            PreparedStatement preparedStatement = conn.prepareStatement(insertQuery);
            preparedStatement.setString(1, Brand);
            preparedStatement.setString(2, ProductName);
            preparedStatement.setDouble(3, Price);
            preparedStatement.setInt(4, quantity);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "PRODUCT ADDED!");
                getTable(mainFrame.JTableAll);
            } else {
                JOptionPane.showMessageDialog(null, "Values Insertion failed", "Alert", JOptionPane.ERROR_MESSAGE);
            }
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    
    
//    GET THE DATA FROM DATABASE
    public void getTable(JTable tb) {
        try {
            Insert ins = new Insert();
            ins.rowCount();
            toConnect();
            String insertQuery = "SELECT * FROM product";
            statement = conn.createStatement();
            rs = statement.executeQuery(insertQuery);

            DefaultTableModel tbModel = (DefaultTableModel) tb.getModel();
            tbModel.setRowCount(0); // Clear existing table data

            while (rs.next()) {
                String id = String.valueOf(rs.getInt("id"));
                String brand = rs.getString("Brand");
                String productName = rs.getString("ProductName");
                String price = String.valueOf(rs.getDouble("Price"));
                String quantity = String.valueOf(rs.getInt("Quantity"));

                String[] tableData = {id, brand, productName, price, quantity};
                tbModel.addRow(tableData);                      
            }
          
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    //SEARCH DATA AND UPDATE THE VALUE
    int SearchDataUpdate(String search) {
        try {
            toConnect();
            String insertQuery = "Select * From product Where id = ?";
            smtm = conn.prepareStatement(insertQuery);
            smtm.setString(1, search);
            rs = smtm.executeQuery();

            if (rs.next()) {
                setID(rs.getString("id"));
                setBrand(rs.getString("brand"));
                setProductName(rs.getString("productName"));
                setPrice(String.valueOf(rs.getDouble("PRICE")));
                setQuantity(String.valueOf(rs.getInt("quantity")));
                return 1;
            } else {
                JOptionPane.showMessageDialog(null, "ID NOT FOUND.", "Alert", JOptionPane.WARNING_MESSAGE);
                return 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
                if (rs != null) {
                    rs.close();
                }
                if (smtm != null) {
                    smtm.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return 0;
    }

    //UPDATE THE VALUE OF THE CURRENT DATA
    void updateProduct(String search, String brand, String productName, double price, int quantity) {
        try {
            toConnect();
            String updateQuery = "UPDATE product SET brand = ?, ProductName = ?, Price = ?, Quantity = ? WHERE id = ?";
            PreparedStatement statement = conn.prepareStatement(updateQuery);
            statement.setString(1, brand);
            statement.setString(2, productName);
            statement.setDouble(3, price);
            statement.setInt(4, quantity);
            statement.setString(5, search);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Product Update Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                getTable(mainFrame.JTableAll);
            } else {
                JOptionPane.showMessageDialog(null, "Product not Found", "not found", JOptionPane.INFORMATION_MESSAGE);
            }

            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ADMIN LOGIN
    int login(String username, String password) throws SQLException {
        try {
            toConnect();
            String insertQuery = "SELECT * FROM admin WHERE Username = ? AND Password = ?";
            smtm = conn.prepareStatement(insertQuery);
            smtm.setString(1, username);
            smtm.setString(2, password);

            rs = smtm.executeQuery();
            if (rs.next()) {
                adminUsername = rs.getString("Username");
                Position = rs.getString("Position");
                return 0;
            } else {
                JOptionPane.showMessageDialog(null, "Account Not Found", "Error Login", JOptionPane.ERROR_MESSAGE);
                setLoginSuccessfully("");
                return 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (smtm != null) {
                smtm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return 0;
    }

    // COUNT THE DATA FROM THE DATABASE
    public int dataCount() throws SQLException {
        int rowCount = 0;
        try {
            toConnect();
            statement = conn.createStatement();
            String insertQuery = "Select count(*) as count from product";
            rs = statement.executeQuery(insertQuery);
            if (rs.next()) {
                rowCount = rs.getInt("count");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error Counting rows", "Alert", JOptionPane.ERROR_MESSAGE);
            rowCount = -1;
            e.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (conn != null) {
                conn.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
        return rowCount;
    }

    // DELETE COLUMN
    public void deleteColumn(int id) {
        try {
            toConnect();
            String insertQuery = "Delete from product where id = ?";
            smtm = conn.prepareStatement(insertQuery);
            smtm.setInt(1, id);
            smtm.executeUpdate();
            conn.close();
            smtm.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // DISPLAY SPECIFIC BRAND ON THE TABLE
    void productBrands(JTable tb, String brands) {
        try {
            toConnect();
            String selectQuery = "SELECT * FROM product WHERE brand = '" + brands + "'";
            statement = conn.createStatement();
            ResultSet rs = statement.executeQuery(selectQuery);

            DefaultTableModel tbModel = (DefaultTableModel) tb.getModel();
            tbModel.setRowCount(0);

            while (rs.next()) {
                String id = String.valueOf(rs.getInt("id"));
                String brand = rs.getString("Brand");
                String productName = rs.getString("ProductName");
                String price = String.valueOf(rs.getDouble("Price"));
                String quantity = String.valueOf(rs.getInt("Quantity"));

                String[] tableData = {id, brand, productName, price, quantity};
                tbModel.addRow(tableData);
            }
            rs.close();
            statement.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

   

    // COUNT THE VALUE OF EACH BRAND
    int countValueEachBrand(String value) {
        int count = 0;
        try {
            toConnect();
            String selectQuery = "SELECT COUNT(*) AS count FROM product WHERE brand = '" + value + "'";
            statement = conn.createStatement();
            ResultSet rs = statement.executeQuery(selectQuery);

            if (rs.next()) {
                count = rs.getInt("count");
            }

            rs.close();
            statement.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    // THIS WILL THROW ERROR MESSAGE IF YOU INSERT PRODUCT NAME THAT ALREADY IN DATABASE
    private boolean isProductExists(Connection conn, String productName) throws SQLException {
        String query = "SELECT COUNT(*) FROM product WHERE LOWER(ProductName) = LOWER(?)";
        PreparedStatement preparedStatement = conn.prepareStatement(query);
        preparedStatement.setString(1, productName);
        boolean exists = false;
        ResultSet resultSet = preparedStatement.executeQuery();
        if (resultSet.next()) {
            int count = resultSet.getInt(1);
            exists = count > 0;
        }
        resultSet.close();
        preparedStatement.close();
        return exists;
    }

}
